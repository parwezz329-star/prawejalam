# CET138 Full-Stack Portfolio

A responsive PHP and MySQL portfolio for the CET138 assignment, with its main learning section focused on HTML, CSS, JavaScript, and Bootstrap and a supporting explanation of full-stack development. A camera button on the homepage lets visitors preview and replace the profile photo. This upload is public and is not password-protected.

## Run with XAMPP on Windows

1. On this computer, `C:\xampp\htdocs\portfolio` is linked directly to this project folder. On a different XAMPP installation, copy the project folder into `C:\xampp\htdocs\portfolio` so `C:\xampp\htdocs\portfolio\index.php` exists.
2. Open the XAMPP Control Panel and start **Apache** and **MySQL**.
3. Visit `http://localhost/phpmyadmin/`, select **Import**, choose this project's `schema.sql`, and run the import. It creates a new `portfolio` database and its tables.
4. Visit `http://localhost/portfolio/`. Select the camera button on the profile image to preview and replace it.

The top-bar message icon opens a public page of contact-form messages. Sender names and email addresses are hidden, but message text is visible to all visitors. Do not send private information through the contact form.

The default database connection is for a local XAMPP installation (`127.0.0.1`, port `3306`, database `portfolio`, user `root`, blank password). These defaults are for local coursework only. Set `PORTFOLIO_DB_HOST`, `PORTFOLIO_DB_PORT`, `PORTFOLIO_DB_NAME`, `PORTFOLIO_DB_USER`, and `PORTFOLIO_DB_PASSWORD` before using another database. Never deploy the blank-root-password configuration to an internet-facing server.

The Bootstrap 5 stylesheet and typefaces load from public CDNs, so an internet connection is needed for those external resources. The portfolio's content, PHP backend, database, uploaded images, and its navigation and image-preview interactions run locally in XAMPP.

If an image upload is rejected with a server upload-size error, edit `C:\xampp\php\php.ini`: set `upload_max_filesize = 5M` and `post_max_size = 6M`, save, and restart Apache. The application independently limits image files to 5 MB and 24 megapixels.

## Evidence and implementation

- `index.php` renders the live portfolio and handles profile-photo uploads, published MySQL projects, and the accessible contact form.
- `contact.php` validates and saves contact submissions to MySQL; `messages.php` publicly lists the message text without sender names or email addresses.
- `app/` contains PDO database access, escaping/CSRF helpers, and verified image-upload handling.
- `schema.sql` creates the portfolio, project, profile-image and contact-message tables.
- `assets/site.css` and `assets/site.js` supply the custom visual design, mobile navigation, and profile-photo previews.
- `uploads/.htaccess` prevents PHP/script execution and directory listing in the image folder.

The live portfolio puts responsive explanations for HTML, CSS, JavaScript and Bootstrap first, followed by a supporting full-stack overview. Scroll and hero animations respect reduced-motion preferences. Its profile-photo upload checks image type, file size and dimensions on the server; because it has no sign-in, anyone who visits the site can replace the displayed photo.

## Before submitting

- Add a portrait with the camera button and upload only images you have permission to use. The photo uploader is public, so anyone can replace the current portrait.
- Add your real projects and links, check that their descriptions accurately reflect your own work, and review all displayed personal details.
- Test the public site, photo upload and contact form in XAMPP.
- Follow your tutor's rules for hosting and Canvas submission. A local `localhost` link is not publicly accessible; arrange approved public hosting if a public link is required.
- Back up the database and the `uploads` folder together. Uploaded images and contact messages remain on the server until removed.
