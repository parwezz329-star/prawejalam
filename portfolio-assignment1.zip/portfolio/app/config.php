<?php
declare(strict_types=1);

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_IMAGE_PIXELS = 24 * 1000 * 1000;

function env_value(string $name, string $default): string
{
    $value = getenv($name);

    return $value === false ? $default : $value;
}
