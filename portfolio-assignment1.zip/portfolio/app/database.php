<?php
declare(strict_types=1);

function database(): PDO
{
    static $connection;

    if ($connection instanceof PDO) {
        return $connection;
    }

    $host = env_value('PORTFOLIO_DB_HOST', '127.0.0.1');
    $port = env_value('PORTFOLIO_DB_PORT', '3306');
    $name = env_value('PORTFOLIO_DB_NAME', 'portfolio');
    $user = env_value('PORTFOLIO_DB_USER', 'root');
    $password = env_value('PORTFOLIO_DB_PASSWORD', '');

    try {
        $connection = new PDO(
            "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
            $user,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]
        );
    } catch (PDOException $exception) {
        error_log('Portfolio database connection failed: ' . $exception->getMessage());
        throw new RuntimeException(
            'The portfolio database is unavailable. Start MySQL in the XAMPP Control Panel and import schema.sql into phpMyAdmin.',
            0,
            $exception
        );
    }

    return $connection;
}
