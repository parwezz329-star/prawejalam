<?php
declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $location): never
{
    header('Location: ' . $location, true, 303);
    exit;
}

function csrf_token(): string
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $provided = $_POST['csrf_token'] ?? '';
    if (!is_string($provided) || !hash_equals(csrf_token(), $provided)) {
        http_response_code(400);
        exit('Invalid or expired form token. Reload the page and try again.');
    }
}

function set_flash(string $message, string $type = 'success'): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function take_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);

    return is_array($flash) ? $flash : null;
}

function post_string(string $key, int $maximumLength): string
{
    $value = $_POST[$key] ?? '';
    if (!is_string($value)) {
        return '';
    }

    $value = trim($value);
    if (mb_strlen($value) > $maximumLength) {
        throw new InvalidArgumentException("The {$key} field is too long.");
    }

    return $value;
}

function save_uploaded_image(array $upload): string
{
    if (!isset($upload['error'], $upload['tmp_name'], $upload['size']) || !is_int($upload['error'])) {
        throw new InvalidArgumentException('Choose an image file to upload.');
    }

    if ($upload['error'] !== UPLOAD_ERR_OK) {
        $message = match ($upload['error']) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The image exceeds the server upload limit.',
            UPLOAD_ERR_NO_FILE => 'Choose an image file to upload.',
            default => 'The image could not be uploaded. Try again.',
        };
        throw new InvalidArgumentException($message);
    }

    if (!is_string($upload['tmp_name']) || !is_uploaded_file($upload['tmp_name'])) {
        throw new InvalidArgumentException('The uploaded file could not be verified.');
    }
    if (!is_int($upload['size']) || $upload['size'] < 1 || $upload['size'] > MAX_IMAGE_BYTES) {
        throw new InvalidArgumentException('Images must be no larger than 5 MB.');
    }

    $imageInfo = @getimagesize($upload['tmp_name']);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($upload['tmp_name']);
    $allowedTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    if ($imageInfo === false || !isset($allowedTypes[$mime]) || ($imageInfo['mime'] ?? '') !== $mime) {
        throw new InvalidArgumentException('Choose a valid JPEG, PNG, or WebP image.');
    }
    if ($imageInfo[0] < 1 || $imageInfo[1] < 1 || $imageInfo[0] * $imageInfo[1] > MAX_IMAGE_PIXELS) {
        throw new InvalidArgumentException('Images must have no more than 24 million pixels.');
    }

    $directory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('The image upload folder could not be created.');
    }

    $filename = bin2hex(random_bytes(24)) . '.' . $allowedTypes[$mime];
    $destination = $directory . DIRECTORY_SEPARATOR . $filename;
    if (!move_uploaded_file($upload['tmp_name'], $destination)) {
        throw new RuntimeException('The image could not be saved. Check that uploads is writable.');
    }

    return 'uploads/' . $filename;
}

function remove_uploaded_image(?string $relativePath): void
{
    if ($relativePath === null || !preg_match('/\Auploads\/[a-f0-9]{48}\.(?:jpg|png|webp)\z/', $relativePath)) {
        return;
    }

    $directory = realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads');
    $file = $directory === false
        ? false
        : realpath($directory . DIRECTORY_SEPARATOR . basename($relativePath));

    if ($directory !== false && $file !== false && dirname($file) === $directory && is_file($file)) {
        if (!unlink($file)) {
            error_log('Portfolio image could not be removed: ' . $file);
        }
    }
}

function database_error_page(Throwable $exception): never
{
    error_log('Portfolio application error: ' . $exception->getMessage());
    http_response_code(503);
    $message = 'The portfolio could not connect to its database. Start MySQL in XAMPP, create the portfolio database by importing schema.sql, then reload this page.';
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Portfolio setup required</title><body style="font:16px/1.6 system-ui,sans-serif;max-width:42rem;margin:12vh auto;padding:24px;color:#192923"><h1>One quick setup step</h1><p>' . e($message) . '</p></body></html>';
    exit;
}
