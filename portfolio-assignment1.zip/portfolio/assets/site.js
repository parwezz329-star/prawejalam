"use strict";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

document.addEventListener("DOMContentLoaded", () => {
  const animatedElements = document.querySelectorAll(
    ".section-title-row, .project-card, .skill-card, .topic-card, .stack-story, .about-copy, .contact-intro, .contact-form"
  );

  if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -24px 0px" });

    document.body.classList.add("motion-ready");
    animatedElements.forEach((element, index) => {
      element.classList.add("reveal");
      if (element.matches(".topic-card, .skill-card, .project-card")) {
        element.style.setProperty("--reveal-delay", `${(index % 4) * 70}ms`);
      }
      revealObserver.observe(element);
    });
  }

  document.querySelectorAll(".image-input[data-preview]").forEach((input) => {
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      const preview = document.getElementById(input.dataset.preview);
      const error = document.getElementById(input.dataset.error);
      const actions = document.getElementById(input.dataset.actions);
      if (!preview) return;

      if (!preview.dataset.originalSrc) {
        preview.dataset.originalSrc = preview.getAttribute("src") || "";
        preview.dataset.originalHidden = String(preview.hidden);
      }

      const restorePreview = () => {
        if (preview.dataset.objectUrl) {
          URL.revokeObjectURL(preview.dataset.objectUrl);
          delete preview.dataset.objectUrl;
        }
        preview.src = preview.dataset.originalSrc;
        preview.hidden = preview.dataset.originalHidden === "true";
        if (actions) actions.hidden = true;
      };

      const showError = (message) => {
        restorePreview();
        if (error) {
          error.textContent = message;
          error.hidden = false;
        }
        input.value = "";
      };

      if (!file) {
        restorePreview();
        if (error) {
          error.textContent = "";
          error.hidden = true;
        }
        return;
      }

      if (file.size > MAX_IMAGE_BYTES) {
        showError("Choose an image no larger than 5 MB.");
        return;
      }

      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
        showError("Choose a JPEG, PNG, or WebP image.");
        return;
      }

      if (error) {
        error.textContent = "";
        error.hidden = true;
      }

      if (preview.dataset.objectUrl) {
        URL.revokeObjectURL(preview.dataset.objectUrl);
      }
      const objectUrl = URL.createObjectURL(file);
      preview.dataset.objectUrl = objectUrl;
      preview.src = objectUrl;
      preview.hidden = false;
      if (actions) actions.hidden = false;
    });
  });

  document.querySelectorAll("[data-cancel-upload]").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.cancelUpload);
      if (!(input instanceof HTMLInputElement)) return;
      input.value = "";
      input.dispatchEvent(new Event("change"));
    });
  });

  document.querySelectorAll("[data-open-upload]").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.openUpload);
      if (input instanceof HTMLInputElement) input.click();
    });
  });

  const menu = document.getElementById("siteMenu");
  const menuToggle = document.querySelector(".menu-toggle");
  if (menu && menuToggle) {
    menuToggle.addEventListener("click", () => {
      const expanded = menu.classList.toggle("show");
      menuToggle.setAttribute("aria-expanded", String(expanded));
    });

    menu.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", () => {
        menu.classList.remove("show");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });
  }
});
