<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php#contact');
}

verify_csrf();

try {
    if (post_string('website', 200) !== '') {
        set_flash('Thanks for reaching out. Your message has been received.');
        redirect('index.php#contact');
    }

    $name = post_string('name', 80);
    $email = post_string('email', 254);
    $message = post_string('message', 5000);

    if ($name === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false || $message === '') {
        throw new InvalidArgumentException('Please provide your name, a valid email address, and a message.');
    }
    $sentAt = time();
    $recentSubmissions = array_values(array_filter(
        $_SESSION['contact_submissions'] ?? [],
        static fn ($timestamp): bool => is_int($timestamp) && $timestamp > $sentAt - 600
    ));
    if (count($recentSubmissions) >= 3) {
        throw new InvalidArgumentException('Please wait a few minutes before sending another message.');
    }

    $connection = database();
    $statement = $connection->prepare(
        'INSERT INTO contact_messages (name, email, message) VALUES (:name, :email, :message)'
    );
    $statement->execute(['name' => $name, 'email' => $email, 'message' => $message]);
    $recentSubmissions[] = $sentAt;
    $_SESSION['contact_submissions'] = $recentSubmissions;
    set_flash('Thanks for reaching out. Your message has been received.');
} catch (InvalidArgumentException $exception) {
    set_flash($exception->getMessage(), 'error');
} catch (Throwable $exception) {
    database_error_page($exception);
}

redirect('index.php#contact');
