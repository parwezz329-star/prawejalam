<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';

$flash = take_flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    try {
        if (post_string('action', 40) !== 'update_profile_image') {
            throw new InvalidArgumentException('That action is not available.');
        }

        $upload = $_FILES['profile_image'] ?? null;
        if (!is_array($upload)) {
            throw new InvalidArgumentException('Choose a profile image to upload.');
        }

        $newImage = save_uploaded_image($upload);
        try {
            $connection = database();
            $statement = $connection->prepare(
                'SELECT setting_value FROM portfolio_settings WHERE setting_key = :key'
            );
            $statement->execute(['key' => 'profile_image']);
            $previousImage = $statement->fetchColumn();

            $statement = $connection->prepare(
                'INSERT INTO portfolio_settings (setting_key, setting_value)
                 VALUES (:key, :value)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
            );
            $statement->execute(['key' => 'profile_image', 'value' => $newImage]);
        } catch (Throwable $exception) {
            remove_uploaded_image($newImage);
            throw $exception;
        }

        if (is_string($previousImage) && $previousImage !== $newImage) {
            remove_uploaded_image($previousImage);
        }

        set_flash('Profile photo updated.');
    } catch (InvalidArgumentException $exception) {
        set_flash($exception->getMessage(), 'error');
    } catch (Throwable $exception) {
        database_error_page($exception);
    }

    redirect('index.php#home');
}

try {
    $projects = database()->query(
        'SELECT id, title, description, technologies, project_url, image_path FROM projects ORDER BY created_at DESC, id DESC'
    )->fetchAll();
    $messageCount = (int) database()->query('SELECT COUNT(*) FROM contact_messages')->fetchColumn();
    $setting = database()->prepare('SELECT setting_value FROM portfolio_settings WHERE setting_key = :key');
    $setting->execute(['key' => 'profile_image']);
    $profileImage = $setting->fetchColumn();
    $profileImageIsCustom = is_string($profileImage) && $profileImage !== '';
    if (!$profileImageIsCustom) {
        $profileImage = 'assets/profile-placeholder.svg';
    }
} catch (Throwable $exception) {
    database_error_page($exception);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Parwej Portfolio — web development projects and coursework in HTML, CSS, JavaScript, Bootstrap, PHP and MySQL.">
  <meta name="theme-color" content="#f7f7f2">
  <title>Parwej Portfolio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/site.css?v=22" rel="stylesheet">
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>
  <header class="site-header">
    <nav class="navbar navbar-expand-lg container site-nav" aria-label="Main navigation">
      <a class="navbar-brand wordmark" href="#home" aria-label="Parwez Alam, home">
        <span class="brand-mark" aria-hidden="true">P</span>
        <span class="brand-name"><span>Parwez</span><span class="brand-surname">Alam</span></span>
      </a>
      <div class="nav-tools">
        <a class="message-indicator" href="messages.php" aria-label="<?= e($messageCount === 1 ? 'Read 1 visitor message' : 'Read ' . $messageCount . ' visitor messages') ?>" title="Read visitor messages">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5h16v11H4zM4.5 7l7.5 6 7.5-6"/></svg>
          <?php if ($messageCount > 0): ?><span class="message-count" aria-hidden="true"><?= $messageCount > 99 ? '99+' : $messageCount ?></span><?php endif; ?>
        </a>
        <button class="navbar-toggler menu-toggle" type="button" aria-controls="siteMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="menu-lines" aria-hidden="true"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="siteMenu">
        <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-4">
          <li class="nav-item"><a class="nav-link" href="#work"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg><span>Work</span></a></li>
          <li class="nav-item"><a class="nav-link" href="#skills"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/></svg><span>Skills</span></a></li>
          <li class="nav-item"><a class="nav-link" href="#evidence"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h14v16H5zM9 9h6M9 13h6M9 17h3"/></svg><span>How I build</span></a></li>
          <li class="nav-item"><a class="nav-link" href="#about"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.6-3.4 3.3-5.5 7-5.5s6.4 2.1 7 5.5"/></svg><span>About</span></a></li>
          <li class="nav-item"><a class="nav-link nav-contact" href="#contact"><span>Contact</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg></a></li>
        </ul>
      </div>
    </nav>
  </header>

  <main id="main">
    <section class="hero container" id="home" aria-labelledby="hero-title">
      <div class="hero-copy">
        <?php if ($flash): ?><div class="notice notice-<?= e($flash['type']) ?>" role="<?= $flash['type'] === 'error' ? 'alert' : 'status' ?>"><?= e($flash['message']) ?></div><?php endif; ?>
        <h1 id="hero-title">Hello, I'm Parwez.<br><span>I build for the web.</span></h1>
        <p class="hero-intro">I'm a computing student building responsive websites and practical web applications with HTML, CSS, JavaScript, Bootstrap, PHP and MySQL.</p>
        <div class="hero-actions">
          <a class="button button-dark" href="#work">View projects <span aria-hidden="true">↘</span></a>
          <a class="button button-quiet" href="#about">About me <span aria-hidden="true">→</span></a>
        </div>
      </div>
      <div class="portrait-wrap">
        <div class="portrait-backdrop" aria-hidden="true"></div>
        <div class="portrait-frame">
          <img id="profilePreview" src="<?= e($profileImage) ?>" alt="<?= $profileImageIsCustom ? 'Portrait of Parwez Alam' : 'Illustrated portrait placeholder for Parwez Alam' ?>" class="portrait-image" data-preview>
          <form class="profile-upload-form" action="index.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="update_profile_image">
            <input class="profile-upload-input image-input" id="profileImage" name="profile_image" type="file" accept="image/jpeg,image/png,image/webp" aria-label="Choose a profile photo" data-preview="profilePreview" data-error="profileImageError" data-actions="profileActions">
            <button class="profile-upload-trigger" type="button" data-open-upload="profileImage" title="Change profile photo" aria-label="Change profile photo">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h3l1.5-2h7L17 7h3v12H4z"/><circle cx="12" cy="13" r="3.5"/></svg>
            </button>
            <div class="profile-upload-actions" id="profileActions" hidden>
              <button class="profile-upload-save" type="submit">Save photo</button>
              <button class="profile-upload-cancel" type="button" data-cancel-upload="profileImage">Cancel</button>
            </div>
            <p class="profile-upload-error" id="profileImageError" role="alert" hidden></p>
          </form>
        </div>
        <span class="orbit orbit-one" aria-hidden="true"></span>
        <span class="orbit orbit-two" aria-hidden="true"></span>
      </div>
    </section>

    <section class="work-section section-pad" id="work" aria-labelledby="work-title">
      <div class="container">
        <div class="section-title-row">
          <h2 id="work-title">Selected <span>work.</span></h2>
          <p>A selection of coursework and personal projects, with the tools used to build them.</p>
        </div>
        <?php if ($projects !== []): ?>
          <div class="row g-4 project-grid">
            <?php foreach ($projects as $project): ?>
              <article class="col-md-6 project-column">
                <div class="project-card">
                  <?php if ($project['project_url']): ?><a class="project-image-link" href="<?= e($project['project_url']) ?>" target="_blank" rel="noopener noreferrer" aria-label="View <?= e($project['title']) ?>"><?php else: ?><div class="project-image-link"><?php endif; ?>
                    <img class="project-image" src="<?= e($project['image_path']) ?>" alt="<?= e($project['title']) ?> project preview" loading="lazy">
                    <?php if ($project['project_url']): ?><span class="project-image-arrow" aria-hidden="true">↗</span><?php endif; ?>
                  <?php if ($project['project_url']): ?></a><?php else: ?></div><?php endif; ?>
                  <div class="project-details">
                    <div class="project-meta"><span><?= e($project['technologies']) ?></span></div>
                    <h3><?= e($project['title']) ?></h3>
                    <p><?= nl2br(e($project['description'])) ?></p>
                    <?php if ($project['project_url']): ?>
                      <a class="project-link" href="<?= e($project['project_url']) ?>" target="_blank" rel="noopener noreferrer">Explore this project <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                  </div>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="empty-work">
            <div><h3>Projects coming soon</h3><p>New work will appear here as it is ready to share.</p></div>
            <a class="button button-dark" href="#contact">Get in touch <span aria-hidden="true">↗</span></a>
          </div>
        <?php endif; ?>
      </div>
    </section>

    <section class="skills-section section-pad" id="skills" aria-labelledby="skills-title">
      <div class="container">
        <div class="section-title-row">
          <h2 id="skills-title">Tools behind <span>this site.</span></h2>
          <p>HTML, CSS, JavaScript and Bootstrap shape the experience. PHP and MySQL handle profile-photo updates and contact messages.</p>
        </div>
        <div class="skill-grid">
          <article class="skill-card frontend-skill">
            <span class="skill-symbol" aria-hidden="true">&lt;/&gt;</span>
            <h3>HTML &amp; accessibility</h3>
            <p>Semantic HTML gives content a clear structure. Thoughtful headings, labels, and landmarks help both people and assistive technologies make sense of a page.</p>
            <span class="skill-tags">SEMANTIC MARKUP · FORMS · ACCESSIBILITY</span>
          </article>
          <article class="skill-card frontend-skill">
            <span class="skill-symbol" aria-hidden="true">#</span>
            <h3>CSS &amp; responsive design</h3>
            <p>CSS turns structure into a visual system. I use the cascade, reusable styles, flexible layouts, and breakpoints to keep content clear on every screen.</p>
            <span class="skill-tags">CASCADE · FLEXBOX · GRID · MEDIA QUERIES</span>
          </article>
          <article class="skill-card">
            <span class="skill-symbol" aria-hidden="true">JS</span>
            <h3>JavaScript &amp; interaction</h3>
            <p>I use JavaScript for the mobile menu and an image preview before changing the profile photo.</p>
            <span class="skill-tags">EVENTS · DOM · PREVIEWS</span>
          </article>
          <article class="skill-card">
            <span class="skill-symbol" aria-hidden="true">B</span>
            <h3>Bootstrap framework</h3>
            <p>Bootstrap supplies the responsive grid and navigation foundation. The site's CSS styles its colours, typography and individual components.</p>
            <span class="skill-tags">BOOTSTRAP 5 · GRID · NAVIGATION</span>
          </article>
          <article class="skill-card supporting-skill">
            <span class="skill-symbol" aria-hidden="true">PHP</span>
            <h3>PHP &amp; server-side logic</h3>
            <p>PHP handles form submissions on the server, checks incoming data, and renders the latest saved portfolio content from the database.</p>
            <span class="skill-tags">PHP · FORMS · SESSIONS</span>
          </article>
          <article class="skill-card supporting-skill">
            <span class="skill-symbol" aria-hidden="true">DB</span>
            <h3>MySQL &amp; full stack</h3>
            <p>MySQL stores project details between visits. PHP reads and updates those records for the live portfolio.</p>
            <span class="skill-tags">MYSQL · PDO · CRUD · PERSISTENCE</span>
          </article>
        </div>
      </div>
    </section>

    <section class="technical-section section-pad" id="evidence" aria-labelledby="evidence-title">
      <div class="container">
        <div class="section-title-row">
          <h2 id="evidence-title">How I build <span>for the web.</span></h2>
          <p>A closer look at the tools I use and the choices behind this site.</p>
        </div>

        <div class="row g-3 topic-grid">
          <article class="col-lg-6"><div class="topic-card">
            <h3>HTML</h3>
            <p>HTML (HyperText Markup Language) gives a page its structure and meaning. I use semantic elements to make the content easier to navigate, maintain and understand with assistive technology.</p>
            <ul class="topic-details">
              <li><strong>Meaningful structure</strong><span>Headings, navigation, main content and footer landmarks give each area a clear purpose and make the page outline easier to follow.</span></li>
              <li><strong>Usable forms</strong><span>Visible labels identify what to enter. Appropriate input types and required-field hints help people provide the right information.</span></li>
              <li><strong>Inclusive content</strong><span>Alternative text describes useful images, while logical reading order and keyboard-accessible controls support different ways of browsing.</span></li>
            </ul>
            <p class="evidence-proof">Semantic sections, labelled forms, a skip link and descriptive image text help visitors find and use the content.</p>
          </div></article>
          <article class="col-lg-6"><div class="topic-card">
            <h3>CSS</h3>
            <p>CSS (Cascading Style Sheets) controls how a page looks and adapts to different screens. I use reusable styles, Grid and Flexbox to keep the layout consistent from desktop to mobile.</p>
            <ul class="topic-details">
              <li><strong>A consistent visual system</strong><span>Reusable colour, spacing and typography choices keep headings, cards, buttons and sections visually related.</span></li>
              <li><strong>Layouts that can adapt</strong><span>Grid and Flexbox arrange content; fluid sizing and media queries adjust the layout when the available space changes.</span></li>
              <li><strong>Interaction and access</strong><span>Hover and keyboard-focus states make controls easier to recognise. Reduced-motion preferences avoid unnecessary animation.</span></li>
            </ul>
            <p class="evidence-proof">Project cards, skills and the introduction reflow for smaller screens, with visible keyboard focus and reduced-motion support.</p>
          </div></article>
          <article class="col-lg-6"><div class="topic-card">
            <h3>JavaScript</h3>
            <p>JavaScript adds interaction in the browser. It listens for actions such as a click or file selection, then updates the page without a full reload.</p>
            <ul class="topic-details">
              <li><strong>Respond to events</strong><span>A listener can open or close the navigation when its button is pressed and keep the button's expanded state accessible.</span></li>
              <li><strong>Give immediate feedback</strong><span>Selecting a new portrait displays a local preview before upload, so the image can be checked first.</span></li>
              <li><strong>Keep trust on the server</strong><span>Browser-side checks improve convenience, not security: users can bypass them, so PHP validates every submitted field and image again.</span></li>
            </ul>
            <p class="evidence-proof">JavaScript manages the mobile menu and image previews; PHP independently checks each image before saving it.</p>
          </div></article>
          <article class="col-lg-6"><div class="topic-card">
            <h3>Bootstrap Framework</h3>
            <p>Bootstrap provides a mobile-first grid and reusable layout styles. I combine its containers and responsive columns with custom CSS for the site's own visual identity.</p>
            <ul class="topic-details">
              <li><strong>Start with small screens</strong><span>Grid classes can leave cards stacked on narrow screens and place them side by side when a wider breakpoint is reached.</span></li>
              <li><strong>Build consistently</strong><span>Container, row, column and spacing classes reduce repeated layout rules across different sections.</span></li>
              <li><strong>Framework plus custom design</strong><span>Bootstrap handles the page grid and base navigation styles; the project's own CSS defines its distinctive palette, type and editorial look.</span></li>
            </ul>
            <p class="evidence-proof">Bootstrap 5.3 handles responsive containers and columns. A small JavaScript interaction keeps the mobile navigation lightweight.</p>
          </div></article>
        </div>
        <aside class="stack-story" aria-labelledby="stack-title">
          <div class="stack-story-copy">
            <h3 id="stack-title">How these front-end skills fit into full stack</h3>
            <p>Full-stack development connects the browser interface to the server-side application and its data storage. The four technologies above create the experience people see and use; PHP processes requests, and MySQL keeps information available between visits.</p>
            <p>For example, the contact form starts with HTML, is styled by CSS and Bootstrap, and benefits from browser interaction. When a visitor sends it, PHP validates the submission and stores it in MySQL for the portfolio owner to review.</p>
          </div>
          <ol class="stack-layers" aria-label="How the front end connects to the back end">
            <li><span>Front end</span><strong>HTML · CSS · JavaScript · Bootstrap</strong><p>Structure the page, present a responsive layout, and respond to visitor actions.</p></li>
            <li><span>Server</span><strong>PHP</strong><p>Receive the request, validate the submission, and apply application rules.</p></li>
            <li><span>Storage</span><strong>MySQL</strong><p>Save the message so the owner can find it in the portfolio.</p></li>
          </ol>
        </aside>
      </div>
    </section>

    <section class="about-section section-pad" id="about" aria-labelledby="about-title">
      <div class="container about-layout">
        <div class="about-copy">
          <h2 id="about-title">I'm Parwez.<br><span>I study and build for the web.</span></h2>
          <p>I'm a computing student developing my skills through web development coursework and practical projects. I build with HTML, CSS, JavaScript and Bootstrap, with PHP and MySQL for server-side features.</p>
          <a class="text-arrow" href="#contact">Contact me <span aria-hidden="true">↗</span></a>
        </div>
      </div>
    </section>

    <section class="contact-section" aria-labelledby="contact-title">
      <div class="container contact-layout">
        <div class="contact-intro"><h2 id="contact-title">Get in <span>touch.</span></h2><p>Send a message using the form.</p>
        </div>
        <form class="contact-form" action="contact.php" method="post">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <div class="honeypot" aria-hidden="true"><label for="website">Leave this field empty</label><input id="website" name="website" tabindex="-1" autocomplete="off"></div>
          <label for="contactName">Your name</label>
          <input id="contactName" name="name" type="text" maxlength="80" autocomplete="name" required>
          <label for="contactEmail">Email address</label>
          <input id="contactEmail" name="email" type="email" maxlength="254" autocomplete="email" required>
          <label for="contactMessage">Your message</label>
          <textarea id="contactMessage" name="message" rows="4" maxlength="5000" required></textarea>
          <button class="button button-light" type="submit">Send a message <span aria-hidden="true">↗</span></button>
        </form>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-layout">
      <a class="wordmark footer-wordmark" href="#home" aria-label="Parwez Alam, back to the top">Parwez Alam</a>
      <span class="footer-year">&copy; <?= date('Y') ?> PARWEZ ALAM</span>
    </div>
  </footer>
  <script src="assets/site.js?v=12" defer></script>
</body>
</html>
