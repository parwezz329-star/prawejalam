<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';

$pageValue = $_GET['page'] ?? '1';
if (!is_string($pageValue) || !preg_match('/\A[1-9][0-9]*\z/', $pageValue)) {
    http_response_code(400);
    exit('Invalid page number.');
}

$requestedPage = filter_var($pageValue, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($requestedPage === false) {
    http_response_code(400);
    exit('Invalid page number.');
}

const PUBLIC_MESSAGE_PAGE_SIZE = 20;

try {
    $connection = database();
    $messageCount = (int) $connection->query('SELECT COUNT(*) FROM contact_messages')->fetchColumn();
    $pageCount = max(1, (int) ceil($messageCount / PUBLIC_MESSAGE_PAGE_SIZE));
    $currentPage = min($requestedPage, $pageCount);
    $offset = ($currentPage - 1) * PUBLIC_MESSAGE_PAGE_SIZE;
    $statement = $connection->prepare(
        'SELECT message, created_at FROM contact_messages
         ORDER BY created_at DESC, id DESC
         LIMIT :page_size OFFSET :page_offset'
    );
    $statement->bindValue(':page_size', PUBLIC_MESSAGE_PAGE_SIZE, PDO::PARAM_INT);
    $statement->bindValue(':page_offset', $offset, PDO::PARAM_INT);
    $statement->execute();
    $messages = $statement->fetchAll();
} catch (Throwable $exception) {
    database_error_page($exception);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#f7f7f2">
  <meta name="description" content="Messages shared by visitors to Parwez Alam's portfolio.">
  <title>Visitor messages | Parwej Portfolio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/site.css?v=22" rel="stylesheet">
</head>
<body>
  <a class="skip-link" href="#main">Skip to messages</a>
  <header class="site-header">
    <nav class="navbar container site-nav messages-nav" aria-label="Message navigation">
      <a class="navbar-brand wordmark" href="index.php#home" aria-label="Parwez Alam, home">
        <span class="brand-mark" aria-hidden="true">P</span>
        <span class="brand-name"><span>Parwez</span><span class="brand-surname">Alam</span></span>
      </a>
      <a class="messages-back" href="index.php#contact">Back to portfolio <span aria-hidden="true">↗</span></a>
    </nav>
  </header>
  <main class="messages-page" id="main">
    <div class="container">
      <header class="messages-heading">
        <p class="eyebrow">From the contact form</p>
        <h1>Visitor <span>messages.</span></h1>
        <p><?= $messageCount ?> <?= $messageCount === 1 ? 'message' : 'messages' ?> shared by visitors.</p>
        <p class="messages-privacy">These messages are public. Names and email addresses are hidden, but anything written in a message can be read by anyone.</p>
      </header>

      <?php if ($messages === []): ?>
        <div class="messages-empty">
          <h2>No messages yet</h2>
          <p>When visitors get in touch, their messages will appear here.</p>
        </div>
      <?php else: ?>
        <ol class="message-list">
          <?php foreach ($messages as $message): ?>
            <li class="message-card">
              <time datetime="<?= e($message['created_at']) ?>"><?= e(date('M j, Y', strtotime($message['created_at']))) ?></time>
              <p><?= nl2br(e($message['message'])) ?></p>
            </li>
          <?php endforeach; ?>
        </ol>
      <?php endif; ?>

      <?php if ($pageCount > 1): ?>
        <nav class="messages-pagination" aria-label="Message pages">
          <?php if ($currentPage > 1): ?>
            <a href="messages.php?page=<?= $currentPage - 1 ?>" rel="prev">← Newer</a>
          <?php endif; ?>
          <span>Page <?= $currentPage ?> of <?= $pageCount ?></span>
          <?php if ($currentPage < $pageCount): ?>
            <a href="messages.php?page=<?= $currentPage + 1 ?>" rel="next">Older →</a>
          <?php endif; ?>
        </nav>
      <?php endif; ?>
    </div>
  </main>
</body>
</html>
